#include "reportecliente.h"

reporteCliente::reporteCliente()
{

}

