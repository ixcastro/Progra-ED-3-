//#ifndef ADMINMENU_H
//#define ADMINMENU_H
//#include "library.h"
//#include "managerest.h"

//class adminMenu
//{
//public:
//    adminMenu();
//    void shareMenu();
//    bool shareLogin();
//    void shareFiles();
//    void insertHall();
//    void insertProd();
//    void insertBrand();
//    void modifyPrice();
//    void consultPrice();
//    void modifyPercentage();
//    void modifyIsBasket();
//    void consultIsBasket();
//    void consultPercentage();
//    managerEST getManagerEST();


//private:
//    managerEST EST;

//    string BANNER ="XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
//    string LOGIN =" __    _____ _____ _____ _____\n"
//                  "|  |  |     |   __|     |   | |\n"
//                  "|  |__|  |  |  |  |-   -| | | |\n"
//                  "|_____|_____|_____|_____|_|___|\n";

//    string MENU = "::::    ::::: :::::::::: ::::    ::: :::    :::      \n"
//                  "+:+:+: :+:+:+ :+:        :+:+:   :+: :+:    :+:      \n"
//                  "+:+ +:+:+ +:+ +:+        :+:+:+  +:+ +:+    +:+      \n"
//                  "+#+  +:+  +#+ +#++:++#   +#+ +:+ +#+ +#+    +:+      \n"
//                  "+#+       +#+ +#+        +#+  +#+#+# +#+    +#+      \n"
//                  "#+#       #+# #+#        #+#   #+#+# #+#    #+#      \n"
//                  "###       ### ########## ###    ####  ########       \n";
//};

//#endif // ADMINMENU_H
