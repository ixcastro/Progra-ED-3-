#ifndef REPORTECLIENTE_H
#define REPORTECLIENTE_H


class reporteCliente
{
public:
    reporteCliente();
    void reportClients();

};

#endif // REPORTECLIENTE_H
